package uz.wtf.durak

/** Durak (36 karta, 2 o'yinchi). Faqat mezbonda ishlaydi. Karta: id = suit*9 + rank (6..A). */
class Engine {
    val deck = ArrayList<Int>()
    val hands = arrayOf(ArrayList<Int>(), ArrayList<Int>())
    var trump = 0
    var attacker = 0
    val attack = ArrayList<Int>()
    val defend = ArrayList<Int>() // attack bilan parallel, -1 = yopilmagan
    var over = false
    var result = -2 // -1 durang, 0/1 = g'olib o'yinchi

    private fun suit(c: Int) = c / 9
    private fun rank(c: Int) = c % 9
    private fun pending() = defend.count { it < 0 }

    fun start() {
        deck.clear()
        for (i in 0 until 36) deck.add(i)
        deck.shuffle()
        hands.forEach { it.clear() }
        attack.clear(); defend.clear()
        over = false; result = -2
        repeat(6) { hands[0].add(deck.removeAt(0)); hands[1].add(deck.removeAt(0)) }
        trump = suit(deck.last())
        fun low(p: Int) = hands[p].filter { suit(it) == trump }.map { rank(it) }.minOrNull() ?: 99
        attacker = if (low(1) < low(0)) 1 else 0
    }

    /** Amallar: "P<id>" karta tashlash, "T" olaman, "B" bito */
    fun handle(p: Int, a: String) {
        if (over) return
        val d = 1 - attacker
        when {
            a.startsWith("P") -> {
                val c = a.substring(1).toIntOrNull() ?: return
                if (!hands[p].contains(c)) return
                if (p == attacker) {
                    val ok = attack.isEmpty() ||
                        attack.any { rank(it) == rank(c) } ||
                        defend.any { it >= 0 && rank(it) == rank(c) }
                    if (!ok || attack.size >= 6 || pending() >= hands[d].size) return
                    hands[p].remove(c); attack.add(c); defend.add(-1)
                } else {
                    val i = defend.indexOfFirst { it < 0 }
                    if (i < 0) return
                    val x = attack[i]
                    val ok = if (suit(c) == suit(x)) rank(c) > rank(x)
                             else suit(c) == trump && suit(x) != trump
                    if (!ok) return
                    hands[p].remove(c); defend[i] = c
                    if (pending() == 0 &&
                        (hands[p].isEmpty() || hands[attacker].isEmpty() || attack.size >= 6)) finish(false)
                }
            }
            a == "T" -> { if (p == d && pending() > 0) finish(true) }
            a == "B" -> { if (p == attacker && attack.isNotEmpty() && pending() == 0) finish(false) }
        }
    }

    private fun beats(c: Int, x: Int) =
        if (suit(c) == suit(x)) rank(c) > rank(x) else suit(c) == trump && suit(x) != trump

    /** Bot (p o'yinchi) navbatdagi amali; navbati bo'lmasa null */
    fun botAction(p: Int): String? {
        if (over) return null
        val h = hands[p]
        fun cheapest(list: List<Int>) = list.minByOrNull { (if (suit(it) == trump) 100 else 0) + rank(it) }
        if (p == attacker) {
            if (attack.isEmpty()) return cheapest(h)?.let { "P$it" }
            if (pending() > 0) return null
            if (attack.size < 6 && hands[1 - p].size > 0) {
                val add = cheapest(h.filter { c ->
                    suit(c) != trump && (attack.any { rank(it) == rank(c) } ||
                        defend.any { it >= 0 && rank(it) == rank(c) })
                })
                if (add != null) return "P$add"
            }
            return "B"
        }
        val i = defend.indexOfFirst { it < 0 }
        if (i < 0) return null
        val c = cheapest(h.filter { beats(it, attack[i]) })
        return if (c != null) "P$c" else "T"
    }

    private fun fill(p: Int) {
        while (hands[p].size < 6 && deck.isNotEmpty()) hands[p].add(deck.removeAt(0))
    }

    private fun finish(taken: Boolean) {
        val d = 1 - attacker
        if (taken) {
            hands[d].addAll(attack)
            hands[d].addAll(defend.filter { it >= 0 })
        }
        attack.clear(); defend.clear()
        fill(attacker); fill(d)
        if (!taken) attacker = d
        if (deck.isEmpty() && (hands[0].isEmpty() || hands[1].isEmpty())) {
            over = true
            result = if (hands[0].isEmpty() && hands[1].isEmpty()) -1 else if (hands[0].isEmpty()) 0 else 1
        }
    }

    /** p o'yinchi uchun holat satri */
    fun view(p: Int): String = listOf(
        hands[p].joinToString(","), hands[1 - p].size, deck.size, trump,
        attack.joinToString(","), defend.joinToString(","),
        if (attacker == p) 1 else 0,
        if (over) (if (result == -1) 0 else if (result == p) 1 else 2) else -1
    ).joinToString(";")
}

/** Holat satrini o'qish. res: -1 davom etmoqda, 0 durang, 1 yutdi, 2 yutqazdi */
class St(s: String) {
    private val f = s.split(";")
    private fun ints(x: String) = if (x.isEmpty()) emptyList() else x.split(",").map { it.toInt() }
    val hand = ints(f[0])
    val opp = f[1].toInt()
    val deck = f[2].toInt()
    val trump = f[3].toInt()
    val atk = ints(f[4])
    val def = ints(f[5])
    val isAtk = f[6] == "1"
    val res = f[7].toInt()
}
