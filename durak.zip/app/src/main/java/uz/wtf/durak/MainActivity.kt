package uz.wtf.durak

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.io.PrintWriter
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors

class MainActivity : Activity() {
    companion object {
        const val PORT = 5555
        val SUITS = arrayOf("♠", "♥", "♦", "♣")
        val RANKS = arrayOf("6", "7", "8", "9", "10", "J", "Q", "K", "A")
    }

    private var engine: Engine? = null
    private var server: ServerSocket? = null
    private var sock: Socket? = null
    private var out: PrintWriter? = null
    private var isHost = false
    private var isBot = false
    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var gen = 0
    private val io = Executors.newSingleThreadExecutor()
    private var last: St? = null

    private lateinit var status: TextView
    private lateinit var table: LinearLayout
    private lateinit var hand: LinearLayout
    private lateinit var btnTake: Button
    private lateinit var btnBito: Button
    private lateinit var btnAgain: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        showMenu()
    }

    override fun onDestroy() {
        closeNet()
        io.shutdown()
        super.onDestroy()
    }

    // ---------- yordamchilar ----------
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(24), dp(16), dp(16))
    }

    private fun tv(s: String, size: Int, bold: Boolean) = TextView(this).apply {
        text = s
        textSize = size.toFloat()
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(6), 0, dp(6))
    }

    private fun btn(label: String, f: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { f() }
    }

    private fun ips(): String = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { ni ->
                ni.inetAddresses.toList()
                    .filter { it is Inet4Address && !it.isLoopbackAddress }
                    .map { "${it.hostAddress}  (${ni.name})" }
            }.joinToString("\n").ifEmpty { "IP topilmadi. Wi-Fi yoki modemni (hotspot) yoqing." }
    } catch (e: Exception) { "IP topilmadi" }

    private fun closeNet() {
        gen++
        last = null
        try { server?.close() } catch (_: Exception) {}
        try { sock?.close() } catch (_: Exception) {}
        server = null; sock = null; out = null; engine = null
    }

    // ---------- menyu ----------
    private fun showMenu(note: String = "") {
        closeNet()
        isBot = false
        val col = column()
        col.addView(tv("DURAK", 32, true))
        col.addView(btn("Bot bilan o'ynash (yakka)") { startBot() })
        col.addView(tv("Yoki 2 kishilik: bitta Wi-Fi yoki modem (hotspot) orqali ulaning.", 14, false))
        col.addView(btn("Server ochish (men mezbonman)") { startHost() })
        val ip = EditText(this)
        ip.hint = "Mezbon IP manzili, masalan 192.168.43.1"
        ip.inputType = InputType.TYPE_CLASS_TEXT
        col.addView(ip)
        col.addView(btn("Ulanish") { join(ip.text.toString().trim()) })
        if (note.isNotEmpty()) col.addView(tv(note, 16, true))
        setContentView(ScrollView(this).also { it.addView(col) })
    }

    // ---------- mezbon ----------
    private fun startHost() {
        isHost = true
        isBot = false
        val g = ++gen
        val col = column()
        col.addView(tv("Raqib kutilmoqda...", 22, true))
        col.addView(tv("Raqibda 'Ulanish' bosib, shu IP manzillardan birini kiritsin (port $PORT):", 14, false))
        col.addView(tv(ips(), 20, true))
        col.addView(btn("Bekor qilish") { showMenu() })
        setContentView(col)
        Thread {
            try {
                val ss = ServerSocket(PORT)
                server = ss
                val s = ss.accept()
                sock = s
                out = PrintWriter(OutputStreamWriter(s.getOutputStream(), "UTF-8"), true)
                val e = Engine().also { it.start() }
                engine = e
                runOnUiThread { if (g == gen) showGame() }
                push()
                val r = BufferedReader(InputStreamReader(s.getInputStream(), "UTF-8"))
                while (true) {
                    val line = r.readLine() ?: break
                    synchronized(e) { e.handle(1, line) }
                    push()
                }
                runOnUiThread { if (g == gen) showMenu("Raqib uzildi") }
            } catch (ex: Exception) {
                runOnUiThread { if (g == gen) showMenu("Xato: ${ex.message}") }
            }
        }.start()
    }

    private fun push() {
        val e = engine ?: return
        val (a, b) = synchronized(e) { Pair(e.view(0), e.view(1)) }
        runOnUiThread { render(St(a)) }
        io.execute { try { out?.println(b) } catch (_: Exception) {} }
        if (isBot) botTurn()
    }

    // ---------- bot ----------
    private fun startBot() {
        closeNet()
        isHost = true
        isBot = true
        engine = Engine().also { it.start() }
        showGame()
        push()
    }

    private fun botTurn() {
        val e = engine ?: return
        val g = gen
        ui.postDelayed({
            if (g != gen) return@postDelayed
            val a = synchronized(e) { e.botAction(1) } ?: return@postDelayed
            synchronized(e) { e.handle(1, a) }
            push()
        }, 900)
    }

    // ---------- mijoz ----------
    private fun join(ip: String) {
        if (ip.isEmpty()) return
        isHost = false
        isBot = false
        val g = ++gen
        setContentView(tv("Ulanilmoqda...", 22, true).apply { setPadding(dp(16), dp(32), dp(16), 0) })
        Thread {
            try {
                val s = Socket()
                s.connect(InetSocketAddress(ip, PORT), 6000)
                sock = s
                out = PrintWriter(OutputStreamWriter(s.getOutputStream(), "UTF-8"), true)
                runOnUiThread { if (g == gen) showGame() }
                val r = BufferedReader(InputStreamReader(s.getInputStream(), "UTF-8"))
                while (true) {
                    val line = r.readLine() ?: break
                    runOnUiThread { if (g == gen) render(St(line)) }
                }
                runOnUiThread { if (g == gen) showMenu("Mezbon uzildi") }
            } catch (ex: Exception) {
                runOnUiThread { if (g == gen) showMenu("Ulanib bo'lmadi: ${ex.message}") }
            }
        }.start()
    }

    // ---------- o'yin ekrani ----------
    private fun act(a: String) {
        if (isHost) {
            val e = engine ?: return
            synchronized(e) { e.handle(0, a) }
            push()
        } else {
            io.execute { try { out?.println(a) } catch (_: Exception) {} }
        }
    }

    private fun showGame() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(24), dp(8), dp(8))
        }
        status = tv("Kuting...", 16, true)
        table = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        hand = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(status)
        root.addView(HorizontalScrollView(this).apply { addView(table) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(tv("Sizning kartalaringiz:", 14, false))
        root.addView(HorizontalScrollView(this).apply { addView(hand) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btnTake = btn("Olaman") { act("T") }
        btnBito = btn("Bito") { act("B") }
        btnAgain = btn("Yangi o'yin") {
            val e = engine
            if (isHost && e != null) { synchronized(e) { e.start() }; push() }
        }
        for (b in listOf(btnTake, btnBito, btnAgain)) row.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row)
        setContentView(root)
        last?.let { render(it) }
    }

    private fun card(c: Int, trump: Int, click: (() -> Unit)?): TextView = TextView(this).apply {
        text = "${RANKS[c % 9]}\n${SUITS[c / 9]}"
        textSize = 20f
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (c / 9 == 1 || c / 9 == 2) Color.RED else Color.BLACK)
        minWidth = dp(54)
        minHeight = dp(80)
        background = GradientDrawable().apply {
            setColor(if (c / 9 == trump) Color.rgb(255, 243, 200) else Color.WHITE)
            setStroke(dp(2), Color.DKGRAY)
            cornerRadius = dp(8).toFloat()
        }
        if (click != null) setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
    }

    private fun render(s: St) {
        last = s
        if (!::status.isInitialized) return
        val pending = s.def.count { it < 0 }
        val role = when {
            s.res == 1 -> "Siz yutdingiz! 🎉"
            s.res == 2 -> "Siz durak bo'ldingiz!"
            s.res == 0 -> "Durang"
            s.isAtk -> when {
                s.atk.isEmpty() -> "Sizning yurishingiz: hujum qiling"
                pending > 0 -> "Raqib himoyalanmoqda (yana karta qo'shishingiz mumkin)"
                else -> "Himoyalandi. Karta qo'shing yoki Bito bosing"
            }
            else -> if (pending > 0) "Himoyalaning yoki Olaman bosing" else "Raqib yurishini kutilmoqda"
        }
        status.text = "Kozir: ${SUITS[s.trump]}   Koloda: ${s.deck}   Raqibda: ${s.opp} ta\n$role"
        table.removeAllViews()
        s.atk.forEachIndexed { i, a ->
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(card(a, s.trump, null))
            if (s.def[i] >= 0) col.addView(card(s.def[i], s.trump, null))
            else col.addView(tv("?", 20, true).apply { gravity = Gravity.CENTER })
            table.addView(col)
        }
        hand.removeAllViews()
        s.hand.sorted().forEach { c -> hand.addView(card(c, s.trump) { act("P$c") }) }
        val going = s.res < 0
        btnTake.isEnabled = going && !s.isAtk && pending > 0
        btnBito.isEnabled = going && s.isAtk && s.atk.isNotEmpty() && pending == 0
        btnAgain.visibility = if (!going && isHost) android.view.View.VISIBLE else android.view.View.GONE
    }
}
