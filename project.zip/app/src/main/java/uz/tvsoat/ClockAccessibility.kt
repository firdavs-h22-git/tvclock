package uz.tvsoat

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/** 2-usul: Maxsus imkoniyatlar xizmati. Overlay ruxsati kerak emas. */
class ClockAccessibility : AccessibilityService() {

    private var overlay: ClockOverlay? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        overlay = ClockOverlay(this, wm, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
        // Xizmat yoqilgan bo'lsa, soat ham yoniq bo'ladi
        Prefs.setEnabled(this, true)
        ClockService.stop(this)
        refresh()
    }

    fun refresh() {
        if (Prefs.enabled(this)) overlay?.show() else overlay?.hide()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        overlay?.hide()
        overlay = null
        instance = null
        return super.onUnbind(intent)
    }

    companion object {
        var instance: ClockAccessibility? = null
    }
}
