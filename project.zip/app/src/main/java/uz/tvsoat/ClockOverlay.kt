package uz.tvsoat

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Ekran burchagida soat chizadi. Window turi tashqaridan beriladi. */
class ClockOverlay(
    private val ctx: Context,
    private val wm: WindowManager,
    private val type: Int
) {
    private var view: TextView? = null
    private var fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private var showSeconds = false
    private val handler = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            view?.text = fmt.format(Date())
            val step = if (showSeconds) 1000L else 60000L
            val now = System.currentTimeMillis()
            handler.postDelayed(this, step - (now % step) + 5)
        }
    }

    fun show(): Boolean {
        hide()

        showSeconds = Prefs.seconds(ctx)
        val pattern = if (Prefs.is24h(ctx)) {
            if (showSeconds) "HH:mm:ss" else "HH:mm"
        } else {
            if (showSeconds) "hh:mm:ss a" else "hh:mm a"
        }
        fmt = SimpleDateFormat(pattern, Locale.getDefault())

        val pxCm = Prefs.pxPerCm(ctx)
        // Raqam balandligi ~ shrift o'lchamining 0.72 qismi
        val textPx = Prefs.sizeCm(ctx) * pxCm / 0.72f
        val pad = (textPx * 0.22f).toInt()
        val margin = (0.5f * pxCm).toInt()

        val tv = TextView(ctx).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_PX, textPx)
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(pad, pad / 2, pad, pad / 2)
            background = GradientDrawable().apply {
                setColor(0x99000000.toInt())
                cornerRadius = textPx * 0.25f
            }
            text = fmt.format(Date())
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = when (Prefs.corner(ctx)) {
            0 -> Gravity.TOP or Gravity.END
            1 -> Gravity.TOP or Gravity.START
            2 -> Gravity.BOTTOM or Gravity.END
            else -> Gravity.BOTTOM or Gravity.START
        }
        lp.x = margin
        lp.y = margin

        return try {
            wm.addView(tv, lp)
            view = tv
            tick.run()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun hide() {
        handler.removeCallbacks(tick)
        view?.let {
            try { wm.removeView(it) } catch (_: Exception) {}
        }
        view = null
    }
}
