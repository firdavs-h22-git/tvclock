package uz.tvsoat

import android.app.Activity
import android.app.PictureInPictureParams
import android.os.Build
import android.os.Bundle
import android.util.Rational

/** Ruxsatsiz usul: soat suzuvchi PiP oynada, boshqa ilovalar ustida turadi. */
class ClockPipActivity : Activity() {

    private var entered = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(ClockView(this))
    }

    override fun onResume() {
        super.onResume()
        if (!entered && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            entered = true
            try {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(23, 10))
                    .build()
                enterPictureInPictureMode(params)
            } catch (e: Exception) {
                finish()
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // PiP oynasi yopilganda (X) activity ham yopiladi
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && !isInPictureInPictureMode) {
            finish()
        }
    }
}
