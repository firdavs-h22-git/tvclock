package uz.tvsoat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ClockService : Service() {

    private lateinit var wm: WindowManager
    private var view: TextView? = null
    private var fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private var showSeconds = false
    private val handler = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            view?.text = fmt.format(Date())
            val step = if (showSeconds) 1000L else 60000L
            val now = System.currentTimeMillis()
            handler.postDelayed(this, step - (now % step) + 5)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, buildNotification())
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        showClock()
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val b: Notification.Builder
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel("soat", "TV Soat", NotificationManager.IMPORTANCE_MIN)
            nm.createNotificationChannel(ch)
            b = Notification.Builder(this, "soat")
        } else {
            @Suppress("DEPRECATION")
            b = Notification.Builder(this)
        }
        return b.setContentTitle("TV Soat ishlayapti")
            .setSmallIcon(R.drawable.ic_clock)
            .build()
    }

    private fun showClock() {
        removeView()
        handler.removeCallbacks(tick)

        showSeconds = Prefs.seconds(this)
        val pattern = if (Prefs.is24h(this)) {
            if (showSeconds) "HH:mm:ss" else "HH:mm"
        } else {
            if (showSeconds) "hh:mm:ss a" else "hh:mm a"
        }
        fmt = SimpleDateFormat(pattern, Locale.getDefault())

        // Raqam balandligi ~ shrift o'lchamining 0.72 qismi
        val textPx = Prefs.sizeCm(this) * Prefs.pxPerCm(this) / 0.72f
        val pad = (textPx * 0.22f).toInt()
        val margin = (0.5f * Prefs.pxPerCm(this)).toInt()

        val tv = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_PX, textPx)
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(pad, pad / 2, pad, pad / 2)
            background = GradientDrawable().apply {
                setColor(0x99000000.toInt())
                cornerRadius = textPx * 0.25f
            }
            text = fmt.format(Date())
        }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = when (Prefs.corner(this)) {
            0 -> Gravity.TOP or Gravity.END
            1 -> Gravity.TOP or Gravity.START
            2 -> Gravity.BOTTOM or Gravity.END
            else -> Gravity.BOTTOM or Gravity.START
        }
        lp.x = margin
        lp.y = margin

        try {
            wm.addView(tv, lp)
            view = tv
            tick.run()
        } catch (e: Exception) {
            stopSelf()
        }
    }

    private fun removeView() {
        view?.let {
            try { wm.removeView(it) } catch (_: Exception) {}
        }
        view = null
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        removeView()
        super.onDestroy()
    }

    companion object {
        fun start(c: Context) {
            val i = Intent(c, ClockService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) c.startForegroundService(i)
            else c.startService(i)
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, ClockService::class.java))
        }
    }
}
