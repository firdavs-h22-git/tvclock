package uz.tvsoat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.WindowManager

/** 1-usul: "boshqa ilovalar ustida ko'rsatish" ruxsati bilan. */
class ClockService : Service() {

    private var overlay: ClockOverlay? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, buildNotification())
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (overlay == null) {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
            overlay = ClockOverlay(this, wm, type)
        }
        if (!overlay!!.show()) stopSelf()
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val b: Notification.Builder
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel("soat", "TV Soat", NotificationManager.IMPORTANCE_MIN)
            )
            b = Notification.Builder(this, "soat")
        } else {
            @Suppress("DEPRECATION")
            b = Notification.Builder(this)
        }
        return b.setContentTitle("TV Soat ishlayapti")
            .setSmallIcon(R.drawable.ic_clock)
            .build()
    }

    override fun onDestroy() {
        overlay?.hide()
        overlay = null
        super.onDestroy()
    }

    companion object {
        fun start(c: Context) {
            val i = Intent(c, ClockService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) c.startForegroundService(i)
            else c.startService(i)
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, ClockService::class.java))
        }
    }
}
