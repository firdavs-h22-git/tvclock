package uz.tvsoat

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.Canvas
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Oyna o'lchamiga moslab katta soat chizadi. */
class ClockView(ctx: Context) : View(ctx) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private var fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private var showSeconds = false

    private val tick = object : Runnable {
        override fun run() {
            invalidate()
            val step = if (showSeconds) 1000L else 60000L
            val now = System.currentTimeMillis()
            postDelayed(this, step - (now % step) + 5)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        showSeconds = Prefs.seconds(context)
        val pattern = if (Prefs.is24h(context)) {
            if (showSeconds) "HH:mm:ss" else "HH:mm"
        } else {
            if (showSeconds) "hh:mm:ss" else "hh:mm"
        }
        fmt = SimpleDateFormat(pattern, Locale.getDefault())
        post(tick)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.BLACK)
        val t = fmt.format(Date())
        paint.textSize = 100f
        val w = paint.measureText(t)
        if (w <= 0f || width == 0) return
        val byWidth = width * 0.92f / w * 100f
        val byHeight = height * 0.8f / 0.72f
        val s = minOf(byWidth, byHeight)
        paint.textSize = s
        val baseline = height / 2f + (0.72f * s) / 2f
        canvas.drawText(t, width / 2f, baseline, paint)
    }
}
