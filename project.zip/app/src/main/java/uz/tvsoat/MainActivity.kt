package uz.tvsoat

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var tvPerm: TextView
    private lateinit var tvSize: TextView
    private lateinit var tvDiag: TextView
    private lateinit var btnPerm: Button
    private lateinit var btnToggle: Button
    private lateinit var btnCorner: Button
    private lateinit var btnSec: Button
    private lateinit var btnH: Button

    private val corners = arrayOf("Yuqori o'ng", "Yuqori chap", "Pastki o'ng", "Pastki chap")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 18f
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun label(size: Float = 18f) = TextView(this).apply { textSize = size }

    private fun row(vararg views: android.view.View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(6), 0, dp(6))
        views.forEachIndexed { i, v ->
            if (i == 0 && v is TextView && v !is Button) {
                r.addView(v, LinearLayout.LayoutParams(0, -2, 1f))
            } else {
                r.addView(v)
            }
        }
        return r
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(48), dp(24), dp(48), dp(24))

        val title = label(28f).apply { text = "TV Soat" }
        root.addView(title)

        tvPerm = label()
        btnPerm = btn("Ruxsat berish") { askPermission() }
        root.addView(row(tvPerm, btnPerm))

        btnToggle = btn("") { toggle() }
        root.addView(row(label().apply { text = "Soat" }, btnToggle))

        tvSize = label()
        root.addView(row(tvSize,
            btn("  −  ") { Prefs.setSizeCm(this, Prefs.sizeCm(this) - 0.1f); changed() },
            btn("  +  ") { Prefs.setSizeCm(this, Prefs.sizeCm(this) + 0.1f); changed() }))

        tvDiag = label()
        root.addView(row(tvDiag,
            btn("  −  ") { Prefs.setDiagonal(this, Prefs.diagonal(this) - 1); changed() },
            btn("  +  ") { Prefs.setDiagonal(this, Prefs.diagonal(this) + 1); changed() }))

        btnCorner = btn("") { Prefs.setCorner(this, Prefs.corner(this) + 1); changed() }
        root.addView(row(label().apply { text = "Joylashuv" }, btnCorner))

        btnSec = btn("") { Prefs.setSeconds(this, !Prefs.seconds(this)); changed() }
        root.addView(row(label().apply { text = "Soniyalar" }, btnSec))

        btnH = btn("") { Prefs.set24h(this, !Prefs.is24h(this)); changed() }
        root.addView(row(label().apply { text = "Format" }, btnH))

        val hint = label(14f).apply {
            text = "Eslatma: santimetr aniq chiqishi uchun televizoringiz diagonalini (dyuym) kiriting. " +
                "Ruxsat oynasi ochilmasa, kompyuterdan: adb shell appops set uz.tvsoat SYSTEM_ALERT_WINDOW allow"
            setPadding(0, dp(16), 0, 0)
        }
        root.addView(hint)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun askPermission() {
        try {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "adb shell appops set uz.tvsoat SYSTEM_ALERT_WINDOW allow",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun toggle() {
        if (Prefs.enabled(this)) {
            Prefs.setEnabled(this, false)
            ClockService.stop(this)
        } else {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Avval ruxsat bering", Toast.LENGTH_LONG).show()
                askPermission()
                return
            }
            Prefs.setEnabled(this, true)
            ClockService.start(this)
        }
        refresh()
    }

    private fun changed() {
        if (Prefs.enabled(this) && Settings.canDrawOverlays(this)) ClockService.start(this)
        refresh()
    }

    private fun refresh() {
        val ok = Settings.canDrawOverlays(this)
        tvPerm.text = "Ruxsat: " + if (ok) "berilgan ✓" else "berilmagan"
        btnToggle.text = if (Prefs.enabled(this)) "Yoniq (o'chirish)" else "O'chiq (yoqish)"
        tvSize.text = "Soat o'lchami: %.1f sm".format(Prefs.sizeCm(this))
        tvDiag.text = "Televizor diagonali: ${Prefs.diagonal(this)} dyuym"
        btnCorner.text = corners[Prefs.corner(this)]
        btnSec.text = if (Prefs.seconds(this)) "Ko'rsatilsin" else "Ko'rsatilmasin"
        btnH.text = if (Prefs.is24h(this)) "24 soat" else "12 soat (AM/PM)"
    }
}
