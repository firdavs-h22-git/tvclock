package uz.tvsoat

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var tvAcc: TextView
    private lateinit var tvPerm: TextView
    private lateinit var tvSize: TextView
    private lateinit var tvDiag: TextView
    private lateinit var btnToggle: Button
    private lateinit var btnCorner: Button
    private lateinit var btnSec: Button
    private lateinit var btnH: Button

    private val corners = arrayOf("Yuqori o'ng", "Yuqori chap", "Pastki o'ng", "Pastki chap")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 18f
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun label(size: Float = 18f) = TextView(this).apply { textSize = size }

    private fun row(vararg views: android.view.View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(6), 0, dp(6))
        views.forEachIndexed { i, v ->
            if (i == 0 && v is TextView && v !is Button) {
                r.addView(v, LinearLayout.LayoutParams(0, -2, 1f))
            } else {
                r.addView(v)
            }
        }
        return r
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(48), dp(24), dp(48), dp(24))

        root.addView(label(28f).apply { text = "TV Soat" })

        // Ruxsat kerak bo'lmagan usul: suzuvchi (PiP) oyna
        root.addView(row(
            label().apply { text = "Suzuvchi soat (ruxsat kerak emas)" },
            btn("Ochish") { startPip() }
        ))

        // 1-usul: Maxsus imkoniyatlar (ruxsat oynasi ochilmaydigan televizorlar uchun)
        tvAcc = label()
        root.addView(row(tvAcc, btn("Maxsus imkoniyatlar") { openAccessibility() }))

        // 2-usul: overlay ruxsati
        tvPerm = label()
        root.addView(row(tvPerm, btn("Overlay ruxsati") { askPermission() }))

        btnToggle = btn("") { toggle() }
        root.addView(row(label().apply { text = "Soat" }, btnToggle))

        tvSize = label()
        root.addView(row(tvSize,
            btn("  −  ") { Prefs.setSizeCm(this, Prefs.sizeCm(this) - 0.1f); changed() },
            btn("  +  ") { Prefs.setSizeCm(this, Prefs.sizeCm(this) + 0.1f); changed() }))

        tvDiag = label()
        root.addView(row(tvDiag,
            btn("  −  ") { Prefs.setDiagonal(this, Prefs.diagonal(this) - 1); changed() },
            btn("  +  ") { Prefs.setDiagonal(this, Prefs.diagonal(this) + 1); changed() }))

        btnCorner = btn("") { Prefs.setCorner(this, Prefs.corner(this) + 1); changed() }
        root.addView(row(label().apply { text = "Joylashuv" }, btnCorner))

        btnSec = btn("") { Prefs.setSeconds(this, !Prefs.seconds(this)); changed() }
        root.addView(row(label().apply { text = "Soniyalar" }, btnSec))

        btnH = btn("") { Prefs.set24h(this, !Prefs.is24h(this)); changed() }
        root.addView(row(label().apply { text = "Format" }, btnH))

        root.addView(label(14f).apply {
            text = "Suzuvchi oyna ruxsatsiz ishlaydi, lekin uning o'lchami va joyini televizor belgilaydi. Santimetr sozlamasi faqat pastdagi usullarda ishlaydi. " +
                "Santimetr aniq chiqishi uchun televizor diagonalini (dyuym) kiriting."
            setPadding(0, dp(16), 0, 0)
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun startPip() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O ||
            !packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        ) {
            Toast.makeText(this, "Bu televizorda suzuvchi oyna (PiP) yo'q", Toast.LENGTH_LONG).show()
            return
        }
        startActivity(Intent(this, ClockPipActivity::class.java))
    }

    private fun openAccessibility() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Sozlamalar → Maxsus imkoniyatlar → TV Soat ni yoqing",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun askPermission() {
        try {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            Toast.makeText(this, "Bu televizorda overlay oynasi yo'q. Maxsus imkoniyatlarni ishlating.", Toast.LENGTH_LONG).show()
        }
    }

    private fun toggle() {
        val acc = ClockAccessibility.instance
        if (!Prefs.enabled(this)) {
            if (acc == null && !Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Avval Maxsus imkoniyatlarda TV Soat ni yoqing", Toast.LENGTH_LONG).show()
                openAccessibility()
                return
            }
            Prefs.setEnabled(this, true)
        } else {
            Prefs.setEnabled(this, false)
        }
        apply()
        refresh()
    }

    private fun changed() {
        apply()
        refresh()
    }

    private fun apply() {
        val acc = ClockAccessibility.instance
        if (acc != null) {
            ClockService.stop(this)
            acc.refresh()
        } else if (Prefs.enabled(this) && Settings.canDrawOverlays(this)) {
            ClockService.start(this)
        } else {
            ClockService.stop(this)
        }
    }

    private fun refresh() {
        tvAcc.text = "Maxsus imkoniyatlar: " + if (ClockAccessibility.instance != null) "yoqilgan ✓" else "o'chiq"
        tvPerm.text = "Overlay ruxsati: " + if (Settings.canDrawOverlays(this)) "berilgan ✓" else "berilmagan"
        btnToggle.text = if (Prefs.enabled(this)) "Yoniq (o'chirish)" else "O'chiq (yoqish)"
        tvSize.text = "Soat o'lchami: %.1f sm".format(Prefs.sizeCm(this))
        tvDiag.text = "Televizor diagonali: ${Prefs.diagonal(this)} dyuym"
        btnCorner.text = corners[Prefs.corner(this)]
        btnSec.text = if (Prefs.seconds(this)) "Ko'rsatilsin" else "Ko'rsatilmasin"
        btnH.text = if (Prefs.is24h(this)) "24 soat" else "12 soat (AM/PM)"
    }
}
