package uz.tvsoat

import android.content.Context
import kotlin.math.hypot
import kotlin.math.roundToInt

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("tvsoat", Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    // Raqam balandligi, santimetrda
    fun sizeCm(c: Context) = sp(c).getFloat("size_cm", 2.0f)
    fun setSizeCm(c: Context, v: Float) {
        val r = ((v.coerceIn(0.3f, 10f)) * 10).roundToInt() / 10f
        sp(c).edit().putFloat("size_cm", r).apply()
    }

    // Televizor diagonali, dyuymda (santimetrni aniq hisoblash uchun)
    fun diagonal(c: Context) = sp(c).getInt("diag", 43)
    fun setDiagonal(c: Context, v: Int) = sp(c).edit().putInt("diag", v.coerceIn(10, 120)).apply()

    // 0=yuqori-o'ng, 1=yuqori-chap, 2=pastki-o'ng, 3=pastki-chap
    fun corner(c: Context) = sp(c).getInt("corner", 0)
    fun setCorner(c: Context, v: Int) = sp(c).edit().putInt("corner", v % 4).apply()

    fun seconds(c: Context) = sp(c).getBoolean("seconds", false)
    fun setSeconds(c: Context, v: Boolean) = sp(c).edit().putBoolean("seconds", v).apply()

    fun is24h(c: Context) = sp(c).getBoolean("h24", true)
    fun set24h(c: Context, v: Boolean) = sp(c).edit().putBoolean("h24", v).apply()

    /** Ekranning 1 santimetri necha piksel ekanini televizor diagonaliga qarab hisoblaydi. */
    fun pxPerCm(c: Context): Float {
        val dm = c.resources.displayMetrics
        val diagPx = hypot(dm.widthPixels.toFloat(), dm.heightPixels.toFloat())
        return diagPx / (diagonal(c) * 2.54f)
    }
}
